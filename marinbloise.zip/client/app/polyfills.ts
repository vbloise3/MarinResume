/**
 * Created by vincebloise on 1/25/17.
 */
// This file includes polyfills needed by Angular 2 and is loaded before
// the app. You can add your own extra polyfills to this file.
import 'node_modules/core-js/es6/symbol';
import 'node_modules/core-js/es6/object';
import 'node_modules/core-js/es6/function';
import 'node_modules/core-js/es6/parse-int';
import 'node_modules/core-js/es6/parse-float';
import 'node_modules/core-js/es6/number';
import 'node_modules/core-js/es6/math';
import 'node_modules/core-js/es6/string';
import 'node_modules/core-js/es6/date';
import 'node_modules/core-js/es6/array';
import 'node_modules/core-js/es6/regexp';
import 'node_modules/core-js/es6/map';
import 'node_modules/core-js/es6/set';
import 'node_modules/core-js/es6/reflect';

import 'node_modules/core-js/es7/reflect';
import 'node_modules/zone.js/dist/zone';